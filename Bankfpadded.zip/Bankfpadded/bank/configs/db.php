<?php
// Database Connection
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$databasename = "bnk";
$conn = mysqli_connect($host, $dbusername, $dbpassword, $databasename);
